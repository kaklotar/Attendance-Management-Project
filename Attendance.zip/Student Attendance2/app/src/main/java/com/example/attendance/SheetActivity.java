package com.example.attendance;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.RestrictionEntry;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class SheetActivity extends AppCompatActivity {

    Button btnPdf;
    LinearLayout linearLayout;
    Bitmap bitmap;
    String storagePermission[];
    Button btnback;
    private static final int PERMISSION_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheet);
        btnback = findViewById(R.id.btnback);
        storagePermission = new String[]{WRITE_EXTERNAL_STORAGE};
        btnback.setOnClickListener(v->onBackPressed());
        
        showTable();
        savepdf();

    }

    private void savepdf() {

        btnPdf.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.R)
            @Override
            public void onClick(View v) {
                Log.d("size",linearLayout.getWidth()+" "+linearLayout.getHeight());
                bitmap = loadBitmapFromView(linearLayout,linearLayout.getWidth(),linearLayout.getHeight());
                try {
                    createPdf();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    private void createPdf() throws IOException {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        float height = displayMetrics.heightPixels;
        float width = displayMetrics.widthPixels;

        int convertHeight =(int)height,
                convertWidth=(int)width;

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(convertWidth,convertHeight,1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        canvas.drawPaint(paint);
        bitmap=Bitmap.createScaledBitmap(bitmap,convertWidth,convertHeight,true);
        canvas.drawBitmap(bitmap,0,0,null);
        document.finishPage(page);

        //write document content
        String targetPdf = "storage/page.pdf";
        File filepath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filepath));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this,"something wrong try again"+e.toString(),Toast.LENGTH_SHORT).show();
        }
        //close document
        document.close();
        Toast.makeText(this,"pdf created successfully",Toast.LENGTH_SHORT).show();
        openPdf();
    }

    private void openPdf() {
        File file = new File("/sdcard/page.pdf");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(file);
        intent.setDataAndType(uri,"application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        try {
            startActivity(intent);
        }
        catch (ActivityNotFoundException e)
        {
            Toast.makeText(this,"no application found",Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap loadBitmapFromView(LinearLayout linearLayout, int width, int height) {

        bitmap = Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        linearLayout.draw(canvas);
        return bitmap;
    }

    private void showTable() {

        DbHelper dbHelper = new DbHelper(this);

        TableLayout tableLayout = findViewById(R.id.tableLayout);
        long [] idArray = getIntent().getLongArrayExtra("idArray");
        int [] rollArray = getIntent().getIntArrayExtra("rollArray");
        String [] nameArray = getIntent().getStringArrayExtra("nameArray");
        String month = getIntent().getStringExtra("month");

        linearLayout = findViewById(R.id.lld);
        btnPdf = findViewById(R.id.btnPdf);

        int DAY_IN_MONTH = getDayInMonth(month);

        //row setup
        int rowSize = idArray.length+1;

        TableRow[] rows = new TableRow[rowSize];
        TextView[] roll_tvs = new TextView[rowSize];
        TextView[] name_tvs = new TextView[rowSize];
        TextView[][]  status_tvs = new TextView[rowSize][DAY_IN_MONTH +1];

        for(int i = 0 ; i < rowSize ; i++) {
            roll_tvs[i] = new TextView(this);
            name_tvs[i] = new TextView(this);

            for(int j = 1 ; j <= DAY_IN_MONTH ; j++) {
                status_tvs[i][j] = new TextView(this);
            }

        }
        //header
        roll_tvs[0].setText("Roll");
        roll_tvs[0].setTypeface(roll_tvs[0].getTypeface(), Typeface.BOLD);

        name_tvs[0].setText("Name");
        name_tvs[0].setTypeface(name_tvs[0].getTypeface(), Typeface.BOLD);


        for (int i = 1; i <= DAY_IN_MONTH ; i++){
            status_tvs[0][i].setText(String.valueOf(i));
            status_tvs[0][i].setTypeface(status_tvs[0][i].getTypeface(), Typeface.BOLD);
        }

        for (int i = 1 ; i < rowSize;i++){
            roll_tvs[i].setText(String.valueOf(rollArray[i-1]));
            name_tvs[i].setText(nameArray[i-1]);

            for (int j = 1; j <= DAY_IN_MONTH ; j++){

                String day = String.valueOf(j);
                if(day.length()==1) day = "0"+day;
                String date = day+"."+month;
                String status = dbHelper.getStatus(idArray[i-1],date);
                status_tvs[i][j].setText(status);
                //01/09.2022
            }
        }

        for(int i = 0 ; i < rowSize; i++){
            rows[i] = new TableRow(this);


            if(i % 2 == 0)
                rows[i].setBackgroundColor(Color.parseColor("#EEEEEE"));
            else
                rows[i].setBackgroundColor(Color.parseColor("#E4E4E4"));

            roll_tvs[i].setPadding(16,16,16,16);
            name_tvs[i].setPadding(16,16,16,16);

            rows[i].addView(roll_tvs[i]);
            rows[i].addView(name_tvs[i]);

            for (int j = 1; j <= DAY_IN_MONTH; j++){
                status_tvs[i][j].setPadding(16,16,16,16);
                rows[i].addView(status_tvs[i][j]);
            }

            tableLayout.addView(rows[i]);
        }
        tableLayout.setShowDividers(TableLayout.SHOW_DIVIDER_MIDDLE);
    }

    private int getDayInMonth(String month) {
            int  monthIndex = Integer.parseInt(month.substring(0,2))-1;
            int year = Integer.parseInt(month.substring(3));
            Calendar calender = Calendar.getInstance();
            calender.set(calender.MONTH,monthIndex);
            calender.set(calender.YEAR,year);
            return calender.getActualMaximum(Calendar.DAY_OF_MONTH);
    }


}